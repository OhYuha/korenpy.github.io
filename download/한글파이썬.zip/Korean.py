
def 말하기 (aprint):
    print(aprint)
def 사용자_입력(aiput):
    input(aiput)
def 반복 (arage):
    for i in range(arage)